INSERT INTO `classify` VALUES (6, 'bjqc');
INSERT INTO `classify` VALUES (2, 'bjsp');
INSERT INTO `classify` VALUES (5, 'fzyp');
INSERT INTO `classify` VALUES (3, 'jjyp');
INSERT INTO `classify` VALUES (7, 'kfyp');
INSERT INTO `classify` VALUES (1, 'lnfz');
INSERT INTO `classify` VALUES (4, 'znsb');
