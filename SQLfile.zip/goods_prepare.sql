INSERT INTO `goods_prepare` VALUES (2, 1, 56.00, 1, 1, '2016-5-13 12:43:19');
