INSERT INTO `goods_checkout` VALUES (1, 1, 56.00, 1, 1605, '2016-05-13 09:37:32');
INSERT INTO `goods_checkout` VALUES (2, 12, 56.00, 1, 1605, '2016-05-13 13:15:09');
