INSERT INTO `pay_type` VALUES (0, '未付款');
INSERT INTO `pay_type` VALUES (1, '已付款');
