INSERT INTO `user` VALUES (1605, 'web项目', 'male', '13723776853', 'java_web@163.com');
INSERT INTO `user` VALUES (1606, 'qq', 'female', '123', '234');
INSERT INTO `user` VALUES (1607, 'ww', 'female', '3221', '23456');
INSERT INTO `user` VALUES (1608, 'rr', 'female', '21456', '3456');
INSERT INTO `user` VALUES (1609, 'uu', 'male', '35657', '209897656');
