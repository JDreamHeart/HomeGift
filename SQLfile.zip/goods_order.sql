INSERT INTO `goods_order` VALUES (1, 1, 56.00, 1, 1605, '2016-05-13 09:45:53', 1);
INSERT INTO `goods_order` VALUES (2, 0, 0.00, 1, 1605, '2016-05-13 13:42:22', 0);
INSERT INTO `goods_order` VALUES (3, 0, 0.00, 1, 1605, '2016-05-13 13:43:36', 0);
INSERT INTO `goods_order` VALUES (4, 0, 0.00, 1, 1605, '2016-05-13 13:45:08', 0);
INSERT INTO `goods_order` VALUES (5, 0, 0.00, 1, 1605, '2016-05-13 13:46:12', 0);
INSERT INTO `goods_order` VALUES (6, 0, 0.00, 1, 1605, '2016-05-13 13:48:32', 0);
